```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
df = pd.read_csv("data-export (1).csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th># ----------------------------------------</th>
      <th>Unnamed: 1</th>
      <th>Unnamed: 2</th>
      <th>Unnamed: 3</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
      <th>Unnamed: 9</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Session primary channel group (Default channel...</td>
      <td>Date + hour (YYYYMMDDHH)</td>
      <td>Users</td>
      <td>Sessions</td>
      <td>Engaged sessions</td>
      <td>Average engagement time per session</td>
      <td>Engaged sessions per user</td>
      <td>Events per session</td>
      <td>Engagement rate</td>
      <td>Event count</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Direct</td>
      <td>2024041623</td>
      <td>237</td>
      <td>300</td>
      <td>144</td>
      <td>47.526666666666700</td>
      <td>0.6075949367088610</td>
      <td>4.673333333333330</td>
      <td>0.48</td>
      <td>1402</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Organic Social</td>
      <td>2024041719</td>
      <td>208</td>
      <td>267</td>
      <td>132</td>
      <td>32.09737827715360</td>
      <td>0.6346153846153850</td>
      <td>4.295880149812730</td>
      <td>0.4943820224719100</td>
      <td>1147</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Direct</td>
      <td>2024041723</td>
      <td>188</td>
      <td>233</td>
      <td>115</td>
      <td>39.93991416309010</td>
      <td>0.6117021276595740</td>
      <td>4.587982832618030</td>
      <td>0.49356223175965700</td>
      <td>1069</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Organic Social</td>
      <td>2024041718</td>
      <td>187</td>
      <td>256</td>
      <td>125</td>
      <td>32.16015625</td>
      <td>0.6684491978609630</td>
      <td>4.078125</td>
      <td>0.48828125</td>
      <td>1044</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3178</th>
      <td>Unassigned</td>
      <td>2024042806</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3179</th>
      <td>Unassigned</td>
      <td>2024043005</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3180</th>
      <td>Unassigned</td>
      <td>2024043006</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3181</th>
      <td>Unassigned</td>
      <td>2024050105</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3182</th>
      <td>Unassigned</td>
      <td>2024050307</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>3183 rows × 10 columns</p>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th># ----------------------------------------</th>
      <th>Unnamed: 1</th>
      <th>Unnamed: 2</th>
      <th>Unnamed: 3</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
      <th>Unnamed: 9</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Session primary channel group (Default channel...</td>
      <td>Date + hour (YYYYMMDDHH)</td>
      <td>Users</td>
      <td>Sessions</td>
      <td>Engaged sessions</td>
      <td>Average engagement time per session</td>
      <td>Engaged sessions per user</td>
      <td>Events per session</td>
      <td>Engagement rate</td>
      <td>Event count</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Direct</td>
      <td>2024041623</td>
      <td>237</td>
      <td>300</td>
      <td>144</td>
      <td>47.526666666666700</td>
      <td>0.6075949367088610</td>
      <td>4.673333333333330</td>
      <td>0.48</td>
      <td>1402</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Organic Social</td>
      <td>2024041719</td>
      <td>208</td>
      <td>267</td>
      <td>132</td>
      <td>32.09737827715360</td>
      <td>0.6346153846153850</td>
      <td>4.295880149812730</td>
      <td>0.4943820224719100</td>
      <td>1147</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Direct</td>
      <td>2024041723</td>
      <td>188</td>
      <td>233</td>
      <td>115</td>
      <td>39.93991416309010</td>
      <td>0.6117021276595740</td>
      <td>4.587982832618030</td>
      <td>0.49356223175965700</td>
      <td>1069</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Organic Social</td>
      <td>2024041718</td>
      <td>187</td>
      <td>256</td>
      <td>125</td>
      <td>32.16015625</td>
      <td>0.6684491978609630</td>
      <td>4.078125</td>
      <td>0.48828125</td>
      <td>1044</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns = df.iloc[0]
df = df.drop(index = 0).reset_index(drop = True)
df.columns = ["channel group","Date_Hour","Users ","Sessions","Engaged sessions","Average engagement time per session","Engaged sessions per user","Events per session","Engagement rate","Event count"]

```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>channel group</th>
      <th>Date_Hour</th>
      <th>Users</th>
      <th>Sessions</th>
      <th>Engaged sessions</th>
      <th>Average engagement time per session</th>
      <th>Engaged sessions per user</th>
      <th>Events per session</th>
      <th>Engagement rate</th>
      <th>Event count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Direct</td>
      <td>2024041623</td>
      <td>237</td>
      <td>300</td>
      <td>144</td>
      <td>47.526666666666700</td>
      <td>0.6075949367088610</td>
      <td>4.673333333333330</td>
      <td>0.48</td>
      <td>1402</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Organic Social</td>
      <td>2024041719</td>
      <td>208</td>
      <td>267</td>
      <td>132</td>
      <td>32.09737827715360</td>
      <td>0.6346153846153850</td>
      <td>4.295880149812730</td>
      <td>0.4943820224719100</td>
      <td>1147</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Direct</td>
      <td>2024041723</td>
      <td>188</td>
      <td>233</td>
      <td>115</td>
      <td>39.93991416309010</td>
      <td>0.6117021276595740</td>
      <td>4.587982832618030</td>
      <td>0.49356223175965700</td>
      <td>1069</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Organic Social</td>
      <td>2024041718</td>
      <td>187</td>
      <td>256</td>
      <td>125</td>
      <td>32.16015625</td>
      <td>0.6684491978609630</td>
      <td>4.078125</td>
      <td>0.48828125</td>
      <td>1044</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Organic Social</td>
      <td>2024041720</td>
      <td>175</td>
      <td>221</td>
      <td>112</td>
      <td>46.918552036199100</td>
      <td>0.64</td>
      <td>4.529411764705880</td>
      <td>0.5067873303167420</td>
      <td>1001</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 3182 entries, 0 to 3181
    Data columns (total 10 columns):
     #   Column                               Non-Null Count  Dtype 
    ---  ------                               --------------  ----- 
     0   channel group                        3182 non-null   object
     1   Date_Hour                            3182 non-null   object
     2   Users                                3182 non-null   object
     3   Sessions                             3182 non-null   object
     4   Engaged sessions                     3182 non-null   object
     5   Average engagement time per session  3182 non-null   object
     6   Engaged sessions per user            3182 non-null   object
     7   Events per session                   3182 non-null   object
     8   Engagement rate                      3182 non-null   object
     9   Event count                          3182 non-null   object
    dtypes: object(10)
    memory usage: 248.7+ KB
    


```python
df["Date_Hour"] = pd.to_datetime(df["Date_Hour"],format = "%Y%m%d%H", errors="coerce")
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 3182 entries, 0 to 3181
    Data columns (total 10 columns):
     #   Column                               Non-Null Count  Dtype         
    ---  ------                               --------------  -----         
     0   channel group                        3182 non-null   object        
     1   Date_Hour                            3182 non-null   datetime64[ns]
     2   Users                                3182 non-null   object        
     3   Sessions                             3182 non-null   object        
     4   Engaged sessions                     3182 non-null   object        
     5   Average engagement time per session  3182 non-null   object        
     6   Engaged sessions per user            3182 non-null   object        
     7   Events per session                   3182 non-null   object        
     8   Engagement rate                      3182 non-null   object        
     9   Event count                          3182 non-null   object        
    dtypes: datetime64[ns](1), object(9)
    memory usage: 248.7+ KB
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>channel group</th>
      <th>Date_Hour</th>
      <th>Users</th>
      <th>Sessions</th>
      <th>Engaged sessions</th>
      <th>Average engagement time per session</th>
      <th>Engaged sessions per user</th>
      <th>Events per session</th>
      <th>Engagement rate</th>
      <th>Event count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Direct</td>
      <td>2024-04-16 23:00:00</td>
      <td>237</td>
      <td>300</td>
      <td>144</td>
      <td>47.526666666666700</td>
      <td>0.6075949367088610</td>
      <td>4.673333333333330</td>
      <td>0.48</td>
      <td>1402</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Organic Social</td>
      <td>2024-04-17 19:00:00</td>
      <td>208</td>
      <td>267</td>
      <td>132</td>
      <td>32.09737827715360</td>
      <td>0.6346153846153850</td>
      <td>4.295880149812730</td>
      <td>0.4943820224719100</td>
      <td>1147</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Direct</td>
      <td>2024-04-17 23:00:00</td>
      <td>188</td>
      <td>233</td>
      <td>115</td>
      <td>39.93991416309010</td>
      <td>0.6117021276595740</td>
      <td>4.587982832618030</td>
      <td>0.49356223175965700</td>
      <td>1069</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Organic Social</td>
      <td>2024-04-17 18:00:00</td>
      <td>187</td>
      <td>256</td>
      <td>125</td>
      <td>32.16015625</td>
      <td>0.6684491978609630</td>
      <td>4.078125</td>
      <td>0.48828125</td>
      <td>1044</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Organic Social</td>
      <td>2024-04-17 20:00:00</td>
      <td>175</td>
      <td>221</td>
      <td>112</td>
      <td>46.918552036199100</td>
      <td>0.64</td>
      <td>4.529411764705880</td>
      <td>0.5067873303167420</td>
      <td>1001</td>
    </tr>
  </tbody>
</table>
</div>




```python
numeric_cols = df.columns.drop(["channel group","Date_Hour"])
df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors='coerce')
df["Hour"] = df["Date_Hour"].dt.hour
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>channel group</th>
      <th>Date_Hour</th>
      <th>Users</th>
      <th>Sessions</th>
      <th>Engaged sessions</th>
      <th>Average engagement time per session</th>
      <th>Engaged sessions per user</th>
      <th>Events per session</th>
      <th>Engagement rate</th>
      <th>Event count</th>
      <th>Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Direct</td>
      <td>2024-04-16 23:00:00</td>
      <td>237</td>
      <td>300</td>
      <td>144</td>
      <td>47.526667</td>
      <td>0.607595</td>
      <td>4.673333</td>
      <td>0.480000</td>
      <td>1402</td>
      <td>23</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Organic Social</td>
      <td>2024-04-17 19:00:00</td>
      <td>208</td>
      <td>267</td>
      <td>132</td>
      <td>32.097378</td>
      <td>0.634615</td>
      <td>4.295880</td>
      <td>0.494382</td>
      <td>1147</td>
      <td>19</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Direct</td>
      <td>2024-04-17 23:00:00</td>
      <td>188</td>
      <td>233</td>
      <td>115</td>
      <td>39.939914</td>
      <td>0.611702</td>
      <td>4.587983</td>
      <td>0.493562</td>
      <td>1069</td>
      <td>23</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Organic Social</td>
      <td>2024-04-17 18:00:00</td>
      <td>187</td>
      <td>256</td>
      <td>125</td>
      <td>32.160156</td>
      <td>0.668449</td>
      <td>4.078125</td>
      <td>0.488281</td>
      <td>1044</td>
      <td>18</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Organic Social</td>
      <td>2024-04-17 20:00:00</td>
      <td>175</td>
      <td>221</td>
      <td>112</td>
      <td>46.918552</td>
      <td>0.640000</td>
      <td>4.529412</td>
      <td>0.506787</td>
      <td>1001</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 3182 entries, 0 to 3181
    Data columns (total 11 columns):
     #   Column                               Non-Null Count  Dtype         
    ---  ------                               --------------  -----         
     0   channel group                        3182 non-null   object        
     1   Date_Hour                            3182 non-null   datetime64[ns]
     2   Users                                3182 non-null   int64         
     3   Sessions                             3182 non-null   int64         
     4   Engaged sessions                     3182 non-null   int64         
     5   Average engagement time per session  3182 non-null   float64       
     6   Engaged sessions per user            3182 non-null   float64       
     7   Events per session                   3182 non-null   float64       
     8   Engagement rate                      3182 non-null   float64       
     9   Event count                          3182 non-null   int64         
     10  Hour                                 3182 non-null   int32         
    dtypes: datetime64[ns](1), float64(4), int32(1), int64(4), object(1)
    memory usage: 261.1+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date_Hour</th>
      <th>Users</th>
      <th>Sessions</th>
      <th>Engaged sessions</th>
      <th>Average engagement time per session</th>
      <th>Engaged sessions per user</th>
      <th>Events per session</th>
      <th>Engagement rate</th>
      <th>Event count</th>
      <th>Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3182</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
      <td>3182.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2024-04-20 01:17:07.278441216</td>
      <td>41.935889</td>
      <td>51.192646</td>
      <td>28.325581</td>
      <td>66.644581</td>
      <td>0.606450</td>
      <td>4.675969</td>
      <td>0.503396</td>
      <td>242.272470</td>
      <td>11.807040</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2024-04-06 00:00:00</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2024-04-13 02:15:00</td>
      <td>20.000000</td>
      <td>24.000000</td>
      <td>13.000000</td>
      <td>32.103034</td>
      <td>0.561404</td>
      <td>3.750000</td>
      <td>0.442902</td>
      <td>103.000000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2024-04-20 02:00:00</td>
      <td>42.000000</td>
      <td>51.000000</td>
      <td>27.000000</td>
      <td>49.020202</td>
      <td>0.666667</td>
      <td>4.410256</td>
      <td>0.545455</td>
      <td>226.000000</td>
      <td>12.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2024-04-26 22:00:00</td>
      <td>60.000000</td>
      <td>71.000000</td>
      <td>41.000000</td>
      <td>71.487069</td>
      <td>0.750000</td>
      <td>5.217690</td>
      <td>0.633333</td>
      <td>339.000000</td>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2024-05-03 23:00:00</td>
      <td>237.000000</td>
      <td>300.000000</td>
      <td>144.000000</td>
      <td>4525.000000</td>
      <td>2.000000</td>
      <td>56.000000</td>
      <td>1.000000</td>
      <td>1402.000000</td>
      <td>23.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>29.582258</td>
      <td>36.919962</td>
      <td>20.650569</td>
      <td>127.200659</td>
      <td>0.264023</td>
      <td>2.795228</td>
      <td>0.228206</td>
      <td>184.440313</td>
      <td>6.886686</td>
    </tr>
  </tbody>
</table>
</div>



# Session And User Over Time


```python
sns.set(style="whitegrid")
```


```python
plt.figure(figsize=(13, 5))
df.groupby("Date_Hour")[["Sessions", "Users "]].sum().plot(ax=plt.gca())
plt.title("Session and Users Over Time")
plt.xlabel("Date_Hours")
plt.ylabel("Count")
plt.show()
```


    
![png](output_14_0.png)
    


# Total User By Channel


```python
plt.figure(figsize=(8,5))
sns.barplot(data=df, x="channel group", y="Users ",estimator=np.sum, palette="viridis")
plt.title("Total User by Channel")
plt.xticks(rotation=45)
plt.show()
```

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_3756\1093053166.py:2: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=df, x="channel group", y="Users ",estimator=np.sum, palette="viridis")
    


    
![png](output_16_1.png)
    


# Average Engagement By Channel


```python
plt.figure(figsize=(8,5))
sns.barplot(data=df, x="channel group", y="Average engagement time per session",estimator=np.mean, palette="magma")
plt.title("Avg Engagement time by Channel")
plt.xticks(rotation=45)
plt.show()
```

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_3756\3494965899.py:2: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=df, x="channel group", y="Average engagement time per session",estimator=np.mean, palette="magma")
    


    
![png](output_18_1.png)
    


# Engagement Rate Distruibution By Channel


```python
plt.figure(figsize=(8,5))
sns.boxplot(data=df, x="channel group", y="Engagement rate",palette="coolwarm")
plt.title("Engagement Rate Distributed by Channel")
plt.xticks(rotation=45)
plt.show()
```

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_3756\494693324.py:2: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.boxplot(data=df, x="channel group", y="Engagement rate",palette="coolwarm")
    


    
![png](output_20_1.png)
    


# Engaged VS Non_Engaged Session


```python
session_df = df.groupby("channel group")[["Sessions","Engaged sessions"]].sum().reset_index()
session_df["Non_Engaged"] = session_df["Sessions"] - session_df["Engaged sessions"]
session_df_melted = session_df.melt(id_vars="channel group", value_vars=["Engaged sessions","Non_Engaged"])

plt.figure(figsize=(8,5))
sns.barplot(data=session_df_melted, x="channel group", y="value", hue="variable")
plt.title("Engaged VS Non_engaged session")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_22_0.png)
    


# Traffics By Hour And Channel


```python
heatmap_data = df.groupby(["Hour","channel group"])["Sessions"].sum().unstack().fillna(0)

plt.figure(figsize=(12,6))
sns.heatmap(heatmap_data, cmap="YlGnBu", linewidth=.5, annot=True, fmt='.0f')
plt.title("Traffics by Hour and Channel")
plt.xlabel("Channel Group")
plt.ylabel("Hour by Day")
plt.show()

```


    
![png](output_24_0.png)
    


# Engagement Rate VS Sessions Over Time


```python
df_plot = df.groupby("Date_Hour")[["Engagement rate","Sessions"]].mean().reset_index()

plt.figure(figsize=(10,5))
plt.plot(df_plot["Date_Hour"], df_plot["Engagement rate"], label="Engagement Rate", color="green")
plt.plot(df_plot["Date_Hour"], df_plot["Sessions"], label="Sessions", color="blue")
plt.title("Engagement Rate VS Session Over Time")
plt.xlabel("Date_Hour")
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_26_0.png)
    



```python

```
